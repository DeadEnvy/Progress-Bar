package com.example.progressbar;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;

public class MainActivity extends AppCompatActivity {
    ProgressBar prgCircle;
    ProgressBar prgHorizontal;
    Button btnOne;
    Button btnTwo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        prgCircle = (ProgressBar)findViewById(R.id.progressBar);
        prgHorizontal = (ProgressBar)findViewById(R.id.progressBar3);
        btnOne = (Button)findViewById(R.id.btn25);
        btnTwo = (Button)findViewById(R.id.btn100);

        btnOne.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                prgCircle.incrementProgressBy(10);
                prgHorizontal.incrementProgressBy(10);
            }
        });

        btnTwo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                prgCircle.incrementProgressBy(-10);
                prgHorizontal.incrementProgressBy(-10);
            }
        });


    }
}
